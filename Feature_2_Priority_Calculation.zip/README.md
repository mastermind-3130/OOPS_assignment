# Feature 2 – Priority Calculation

This is a Feature 2 patch package for the supplied OOPS_assignment project.

## Contents
- `PriorityCalculator.java`
- `WeightedPriorityCalculator.java`
- Updated `IncidentService.java` (replace the existing file)
- `docs/feature-2-priority.md`

## Apply
Copy the `src/` and `docs/` folders into the root of your project, allowing the
updated `IncidentService.java` to replace the existing file.

Branch name: `feature/priority-calculation`

The implementation uses the existing project enums and `Incident.applyPriority()`.
The score thresholds and 50-user escalation are documented in `docs/feature-2-priority.md`.
